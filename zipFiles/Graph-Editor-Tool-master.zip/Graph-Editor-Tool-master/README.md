# Garph-Editor-Tool
A GUI application for creating nodes and adding edges just by clicking on the screen. Animation of graph vertices being traversed can be seen for different graph algorithms. This is done using PyGame module in python.
